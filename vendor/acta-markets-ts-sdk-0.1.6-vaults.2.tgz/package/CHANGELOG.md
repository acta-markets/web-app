# Changelog

## 0.1.6-vaults.2

Changed:

- Vault events carry absolute post-state instead of deltas: `VaultStateTail` (`state`) on every event that writes hot vault fields, `VaultConfigTail` (`config`) on config events, whole `VaultPolicyRow` / `VaultDelegateRow` rows. Fields a tail already carries are gone from the events.
- `VaultDepositRequested` / `VaultWithdrawRequested` carry `createdAt`; `VaultCreated` carries decimals; `VaultConfigured` carries the delegate row, policy, config and state.
- Batch capital events carry each user's post-state.
- `Vault.capitalGeneration` (increments at final redemption) and `Vault.managerStakeShares`; `reserved` is 30 words.
- `unlockManagerStake` marks the vault writable.

## 0.1.6-vaults.1

Added:

- `ClientRole` and `WsEndpointKind` include `"vault"`.
- Vault program errors (1100–1156) carry messages.
- `flows.nextCapitalStep` / `planWithdrawals`: the reference operator's capital crank as pure functions over the vault DTO.
- `flows` vault rules: depositor and operator action predicates checked against the contract FSM; self-processed withdrawals are blocked in `closing` and in unpriced `idle` until `processIdleWithdrawal`.
- `pythPriceFeedAccount` / `resolveVaultPriceUpdates`: Pyth push-oracle price accounts for `processEquity`.
- `pythPriceFeedAccount` rejects a shard outside u16.
- `Vault.deposit_window_set_ts`: chain time of the last `SetAcceptingDeposits`, or `null`.
- wSOL helpers: `buildWrapSolInstructions`, `syncNativeInstruction`, `closeTokenAccountInstruction`, `NATIVE_MINT`.
- Vault capital batches take at most `VAULT_CAPITAL_BATCH_USERS` (3) users: a four-user batch overflows the 1232-byte packet.
- `SwapQuote` names the leg with `direction` (`main_to_second` / `second_to_main`) instead of `input_mint` / `output_mint`.
- Vault rebalance wire header is 28 bytes (conversions 27); routes go through `JUPITER_V6_PROGRAM` only.
- Recovery/closing/emergency conversion builders no longer take `direction` and use a 27-byte header; `spotRebalance` takes `VaultRebalancePlan`.
- `VaultHttpClient.vaultDepositRequests` / `vaultWithdrawRequests`: paged pending request queues.
- `@acta-markets/ts-sdk/http`: `VaultHttpClient` and DTO types for the vault read API; `VaultApiError.retryable` for 429 and 503 except `db_disabled`.
- Auth challenges are bound to the signing identity: takers to their wallet, vault operators to their operator and vault PDA.
- Open/Settle/Liquidate discover two unknown mint programs with one RPC; supplied programs avoid lookup.
- ATA planning derives each address once. Vault helpers share the existing strict u64 validator; accepted values and instruction bytes are unchanged.
- Swap routes accept repeated canonical accounts, preserve their order, and keep PDA signing inside CPI.
- Swap retries accept caller UUIDs, normalized to lowercase; swap slippage is a wire `u16`.
- Vault auth and recovery callbacks stay on their operator connection.
- Owner execution lookup: `GetOrderStatus` on `/vault` and the three standard endpoints.
- Typed `/vault` projection notifications.
- Swap amounts and deadlines: backend-compatible `WsU64String` decimal strings, full u64 in both directions.
- `/vault` operator authentication; typed, idempotent rebalance/recovery quote-submit messages with stable error codes.
- Typed depositor/manager planning: automatic PDA/ATA derivation and legacy-safe capital batches.
- Typed manager governance, position lifecycles and route-bound Jupiter spot/recovery planners, including mixed legacy SPL/Token-2022.
- V1 manager API: separate position reference/quote types, Rust-parity addresses and complete static policy/mask/swap checks.
- `VaultManagerPlanner.fromVault`: existing vault account plus transaction actor.
- Vault PDA helpers (`findVaultPda`, `findVaultPolicyPda`, `findVaultDelegatePda`, `findPendingVaultUpdatePda` and the request/escrow PDAs), `assertSupportedVault`, `timelocked`, `decodeActaEventsFromLogsScoped`, `VaultDelegatePermission` / `hasVaultPermission`.
- `lookupTables` option on `buildAndSignTransactionFromIxs`, `sendAndConfirmIxs` and `ActaChainClient`.

Fixed:

- `ORACLE_OFFSET_FEED_ID` is 64 (was 96, which points into `reserved`). `ORACLE_OFFSET_AUTHORITY` is kept for compatibility; the Oracle account has no authority field.
- `computeUserPriceFromGross` rejects `feeBps` outside `0..=10000`; order signature helpers reject signatures that are not 64 bytes.
- Position, PremiumConfig, Maker and Oracle decoders accept accounts longer than the current layout; Market requires at least its size. Version, flag and reserved-byte checks are unchanged.

## 0.1.6

- Validate the server's canonical maker/taker auth challenge before invoking any signer, including reconnects and replacement challenges. Raw clients can use `validateAuthChallenge`; authentication and order-signing wire bytes are unchanged.
- Quote signing derives the market PDA locally and validates its program, chain, option type and token pair before calling the signer. The primary RFQ strike works without alternative strikes.
- Sponsored transaction signing rejects a declared signer address that differs from the required signature slot.

## 0.1.5

- Order lifecycle callbacks require `orderVersion`; missing or invalid wire versions are rejected before dispatch.
- `submitQuoteSigned` and `submitReplaceQuoteSigned` reject if authentication changes while signing and do not send on the replacement session.

## 0.1.4

- Discard auth results and event continuations from old connections and signatures for superseded challenges.
- A new auth provider opens a new connection and clears the previous implicit resume credential. Resume write failures emit `error`.
- Manual reconnect cancels the previous reconnect timer.
- Timed-out unsent requests leave the Welcome queue. Duplicate pending IDs are rejected; synchronous write failures clear pending requests. Queue discards return `queue_overflow`.
- Request IDs remain UUIDs without Web Crypto.
- Sponsored transactions select the required transaction signer's signature.

## 0.1.3

- `GetOrderStatus`: `/maker`, `/maker/data`, `/taker`, matching the backend. Public API and wire formats unchanged.

## 0.1.2

- Required: `Welcome.server_time_unix_ms`, `AuthSuccess.expires_at`, `RfqBroadcast.sent_at_unix_ms`, `instruction_index` on all six known chain events. Missing/null fields fail before dispatch; wire units and protocol version are unchanged.
- `authenticated` always includes resume credential expiry in Unix seconds, not socket lifetime. Unknown future event variants retain existing handling.

## 0.1.0-beta - 2026-09-03

- Backend wire fields: `RfqBroadcast.sent_at_unix_ms`, position `reconciliation_status`, `unrenderable` / `unrenderable_positions`, `GetPositions` filters, chain-event `instruction_index`, `QuoteRejected` reasons `unauthorized` / `internal_error`, optional `EarnAssetSummary.min_apr/max_apr`, `FEATURE_*` constants.
- Wire errors: `ServerError`. SDK errors: `ClientError` (`generic`, `feature_unsupported`, `unsafe_integer`). The `error` event carries `ActaWsClientError`.
- Typed `ActaWsClientEvents` without an index signature; new `makerCapsUpdated`, `quoteCheck`, `tokenCaps`, `unknownMessage` events.
- Every (re)auth re-reads taker `GetMyActiveRfqs` + `GetPositions`, or maker `GetMmSummary` + `GetActiveRfqs` + `GetMyQuotes` + `GetMyTrades`, by endpoint plane. No `Subscribe` on `/maker/data`.
- `cancelOnDisconnect`; missing requested `Welcome` features cause terminal `feature_unsupported`, without reconnect.
- Silent sockets reconnect after `pongTimeoutMs` (10s). Backoff resets after `backoffResetAfterMs` (30s) of uptime past Welcome.
- Promise API: `request(responseType, message)` correlates by `request_id`; `getPositionsAsync`, `getMyActiveRfqsAsync`, `getActiveRfqsAsync`, `checkQuoteAsync`, `getMmSummaryAsync`, `getMyQuotesAsync` reject with `ActaWsRequestError`.
- Full-u64 `nonce: bigint` in `QuoteMessage`, `ReplaceQuoteMessage`, `QuoteReceivedMessage`: exact inbound parsing, outbound bare JSON numbers. `generateNonce()` returns a random u64 bigint.
- Other inbound literals above 2^53 emit `unsafe_integer` once per message type per connection; dispatch continues.
- `state.positionsPartial` marks capped `MmSummary` positions. `connected` means open and unauthenticated, including after `LogoutSuccess`. `onerror` emits `disconnected` before reconnect. Failed auth closes the socket for `connectAndAuthenticate` retry.

## 0.0.26-beta - 2026-07-15

- Narrow browser imports: `chain`, `ws`, `ws/keypair`, `types`, `nonce`.
- Tighter order, settlement and program-ID handling.
- Backend-compatible WebSocket errors and referral/invite messages.

## 0.0.25-beta

- Governance and timelock bindings; clean, side-effect-free, reproducible `prepack` builds.

## 0.0.24-beta

- `getMakerBalances` / `MakerBalances` → `getMmSummary` / `MmSummaryData`. Balances: `MakerBalanceCapInfo { mint, symbol, decimals, deposited, committed, available }`.
- Owner-only `PositionUpdated.caps_snapshot`; no follow-up `GetMyCaps` needed.
- `AuthSuccess.maker_pda`; `authenticated` callback: `(sessionId, expiresAt, makerPda)`.
- `MakerPositionInfo` / `MakerQuoteInfo` / `MakerTradeInfo`: underlying/quote `mint/symbol/decimals`. `MakerPositionInfo`: `status` union (`"none" | "open" | "funded" | "liquidated" | "settled"`) and `settlement_price`.
- New events: `QuoteRejected`, `BatchQuotesAck`, `CancelAllQuotesAck`.
