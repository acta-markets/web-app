# Acta TypeScript SDK

WebSocket RFQ clients, wallet authentication, order signing, and Solana instructions.

## Install

```bash
npm install @acta-markets/ts-sdk@0.1.6-vaults.2
```

Supports ESM and CommonJS.

| Import | Use |
| --- | --- |
| `@acta-markets/ts-sdk/ws` | WebSocket clients, wallet auth and sponsored transactions |
| `@acta-markets/ts-sdk/chain` | Account reads, PDAs, order signing and instruction builders |
| `@acta-markets/ts-sdk/http` | Vault read API client and DTOs |
| `@acta-markets/ts-sdk/ws/keypair` | Node keypair authentication |
| `@acta-markets/ts-sdk/types` | Shared types |
| `@acta-markets/ts-sdk/nonce` | Maker nonce generation |

For browser trading apps, import from `/ws` to avoid loading the chain client and IDL.

## Connect a wallet

```ts
import {
  ActaWsClient,
  WalletAuthProvider,
  type WalletLike,
} from "@acta-markets/ts-sdk/ws";

export function connectTaker(wallet: WalletLike) {
  const client = new ActaWsClient({
    url: "wss://devnet-api.acta.markets",
    role: "taker",
  });

  client.on("error", console.error);
  client.on("marketDescriptors", console.log);
  client.on("quoteReceived", console.log);
  client.on("authenticated", () => {
    client.getMarketDescriptors({ active_only: true });
    client.getPositions();
    client.subscribe(["chain_events"]);
  });

  client.connectAndAuthenticate(new WalletAuthProvider(wallet));
  return client;
}
```

Use `wss://beta-api.acta.markets` for mainnet. The client adds the endpoint path
from its role.

`WalletLike` supplies a public key and `signMessage(Uint8Array)`.
`CustomAuthProvider` supports remote signers; `KeypairAuthProvider` supports Node.
The client validates authentication challenges before calling the signer. Raw
clients must call `assertAuthChallenge` before signing a server challenge.

Register handlers before connecting. Wait for `authenticated` before trading;
`connectAnonymous()` supports browsing without a wallet. Keep the same auth
provider for reconnects; replace it when the wallet changes.

## Vault operator WebSocket

Bind one connection to one Vault. Reconnect performs the Vault auth handshake
again so a rotated or revoked delegate is not restored from an old session id.

```ts
import { ActaWsClient, WalletAuthProvider } from "@acta-markets/ts-sdk/ws";

const vault = new ActaWsClient({
  url: "wss://api.example.com",
  role: "vault",
  vaultPda,
});
vault.connectAndAuthenticate(new WalletAuthProvider({
  publicKeyBase58: operatorPubkey,
  signMessage: (message) => wallet.signMessage(message),
}));
```

A primary delegate with `SIGN_MAKER_QUOTES` uses `submitQuoteSigned`,
`submitReplaceQuoteSigned`, batch and cancellation methods. Rebalance and
governance recovery use `requestVaultSwapQuote`; after the wallet signs the
returned `tx_base64`, call `submitVaultSwap`. `swapSubmitResult` means the
transaction was durably accepted for keeper submission, not confirmed on
Solana. `requestVaultSwapQuote` accepts a UUID
`request_id`; reuse it with the same arguments when retrying. Omitting it
generates a new ID. Returned IDs use lowercase UUID syntax. Vault failures
use stable `vault_*` error codes and do not expose backend error text.

Vault swap amounts and deadlines are `WsU64String` decimal strings,
including values above JavaScript's safe-integer range. Pass `amount.toString()`
from a `bigint`, and use `BigInt(result.in_amount)` for
arithmetic on responses. `valid_until` uses Unix seconds. Other WS numeric fields keep their
existing representation.

`ActaWsClient` validates the canonical Acta auth challenge before invoking an auth
provider. Raw WebSocket integrations must call `assertAuthChallenge` first; pass
the expected wallet for taker authentication. Vault integrations must use
`assertVaultAuthChallenge` with the configured operator and vault. Never send arbitrary endpoint text
to a key that signs orders. `buildSignedQuoteFromRfq` also derives the market PDA
from the RFQ terms under `getActaProgramId()` before quote signing. Set an alternate
program only from your deployment configuration. Low-level signing helpers expect
caller-verified inputs; mint selection and pricing remain the strategy's job.

## Request and accept a quote

Wait for `marketDescriptors` before creating an RFQ. The SDK checks quantity
against the market's `size_rule`. Prices and strikes use 1e9 fixed-point units;
quantity uses the underlying mint's atomic units for both calls and puts.

Register the quote and signing handlers before requesting or accepting a quote.
The application chooses which quote to accept and handles wallet approval.

```ts
import {
  type ActaWsClient,
  type QuoteReceivedMessage,
  type WalletLike,
  signSponsoredTxBase64,
} from "@acta-markets/ts-sdk/ws";

export function registerTradingHandlers(
  client: ActaWsClient,
  wallet: WalletLike,
  showQuote: (quote: QuoteReceivedMessage) => void,
  approvedMessage: (orderId: string) => Promise<Uint8Array>,
) {
  client.on("rfqCreated", (rfq) => console.log(rfq.rfq_id, rfq.expires_at));
  client.on("quoteReceived", showQuote);
  client.on("sponsoredTxToSign", async (orderIdHex, txBase64, signatureDeadline) => {
    try {
      const signedTxBase64 = await signSponsoredTxBase64({
        txBase64,
        taker: wallet,
        expectedMessageBytes: await approvedMessage(orderIdHex),
      });
      await client.submitSignedSponsoredTx({ orderIdHex, txBase64: signedTxBase64 });
    } catch (error) {
      console.error("Signing or submission failed", orderIdHex, signatureDeadline, error);
    }
  });
}

export async function acceptChosenQuote(client: ActaWsClient, quote: QuoteReceivedMessage) {
  await client.acceptQuote(quote.rfq_id, quote.maker, quote.order_id);
}
```

Once authenticated and the market descriptor has arrived:

```ts
await client.createRfq({
  market: marketPdaBase58,
  position_type: "cash_secured_put",
  strike: 136_000_000_000,
  quantity: 20_000_000,
  timeoutSeconds: 31,
});
```

`approvedMessage` must independently build the exact message from the accepted
order, configured program/accounts and approved transaction parameters using the
chain SDK. Never derive it by copying the server's `txBase64`. The mandatory
`expectedMessageBytes` comparison happens before the wallet is called and binds
all instructions, signer/writable flags, fee payer, blockhash and ALT references.
Refreshing a blockhash requires a new approved message. ALT references must be
resolved against trusted table contents when building that message.

The helper fills the taker's signature slot (index 1; index 0 is the relayer).
It does not render a wallet preview. Applications that deliberately trust server
construction can choose `signSponsoredTxBase64Unverified`; that API performs no
intent check. This is an explicit API migration: the safe helper no longer accepts
only a transaction and signer. The SDK does not independently choose an economic
route or promise that an approved trade is profitable.

Wallet-standard signature maps are indexed by the required transaction signer,
not by their first entry. A missing required signature or a declared wallet address
that differs from the required signer is rejected.

`buildSignedQuoteFromRfq` derives the market PDA locally and checks the configured
Acta program, Solana chain, option type and collateral/settlement mints before
signing. It accepts the primary RFQ strike and any listed alternative strike.
These checks make no RPC requests; the maker still chooses the quote's economics.

An expired RFQ requires a new RFQ. A refreshed quote has a new `order_id` and
requires a new acceptance. Do not automatically replay acceptance or transaction
submission after reconnect.

Complete signing before `signatureDeadline` (Unix seconds). Discard approval if
the wallet or connection changes. `signSponsoredTxBase64Unverified` is available
only for applications that deliberately trust server-built transactions.

Keep unresolved order IDs across reconnects and query `getOrderStatus(orderIdHex)`.
A timeout or `unknown` status does not prove non-execution. Do not automatically
repeat acceptance or submission; a refreshed quote needs a new acceptance.
Match response and `RequestError` messages by `request_id`; inspect the typed
`error.type` for the reason.

## Makers

Maker access requires registration. Use `role: "maker"` for quoting and
`makerEndpoint: "data"` for maker reads.

`buildSignedQuoteFromRfq` derives and verifies the market PDA before signing.
Configure the trusted Acta program and chain locally; your strategy supplies
the price, mint allowlist and decimal inputs.

## On-chain operations

Import account fetchers, PDA helpers and instruction builders from `/chain`.
`flows.buildOpenPositionFlowIxs` builds the maker verification and open-position
instructions. Supply `programId` explicitly when targeting another deployment.

For maker reads, configure `role: "maker", makerEndpoint: "data"`.
`GetOrderStatus` is accepted on `/maker/data`, `/maker`, `/taker` and `/vault`, subject to
ownership checks. Prefer the data connection to keep reads off the quote socket.

Save resume credentials per wallet and environment, including `expiresAt` from
`authenticated`. Pass a still-valid credential as `{ sessionId }` to
`connectAndAuthenticate`. The SDK falls back to fresh auth on `session_expired`;
fresh auth does not restore ownership of an older credential's pending signature.

## APR and APY previews

`computeApyFromScaledPrices` values collateral at spot for **both calls and puts**.
Use it for display; the program calculates on-chain collateral.
The helper requires `spotPrice1e9` at runtime for both position types.

For backend-derived previews, use `TokenMarketsInfo.reference_price` and an
indicative premium from the same response. Omit the preview when its indicative
is stale or the premium is absent. No browser Pyth connection is needed.

```ts
import { computeApyFromScaledPrices } from "@acta-markets/ts-sdk/ws";

const { apr, apy, premiumNotional } = computeApyFromScaledPrices({
  positionType: "cash_secured_put",
  underlyingAmount: 10,
  grossPremiumPerUnit1e9: 2_000_000_000,
  strike1e9: 136_000_000_000,
  spotPrice1e9: 135_000_000_000,
  secondsToExpiry: 7 * 24 * 60 * 60,
});
```

With `dt = expiry_ts - now` in seconds and a 365-day year:

- `termYield = premiumNotional / collateralNotional = price / spotPrice`
- `apr = termYield * (secondsPerYear / dt)`
- `apy = (1 + termYield)^(secondsPerYear / dt) - 1`

APR and APY are ratios (`0.1` means 10%), not guaranteed returns. The helper
returns zero APR/APY when `dt <= 0`. Prices use 1e9 scale; `underlyingAmount`
uses human units. Bigint prices are converted to floating-point values for display.

## Solana instructions

For reconciliation after a send/confirmation failure, call
`buildAndSignTransactionFromIxs`, retain its `signature`, then use
`sendAndConfirmSignedTransaction`. The `sendAndConfirmIxs` convenience helper
returns the signature only after confirmation; timeout or abort does not prove
that a submitted transaction failed.

Build the minimal instruction set for `open_position` (maker ed25519 verify + open ix):

```ts
import { chain } from "@acta-markets/ts-sdk";

const built = await chain.flows.buildOpenPositionFlowIxs({
  programId, // optional; scopes order hash, every PDA, and the instruction together
  underlyingMint,
  quoteMint,
  expiryTs,
  isPut,
  positionType,
  strike,
  quantity,
  price,
  validUntil,
  nonce,
  user,
  makerOwner,
  makerQuoteSigning,
  makerSigner,
  keeper: user,
});

// built.ixs = [makerSigIx, openPositionIx]
```

### Program ID

The SDK targets the mainnet program id from `src/generated/programs`. For an
individual flow, prefer its explicit `programId`: the flow uses that same value
for the order preimage, every PDA derivation, and the instruction program.
The process-global override remains available for tests/devnet code that cannot
thread a scoped value:

```ts
import type { Address } from "@solana/addresses";
import { setActaProgramId, clearActaProgramId } from "@acta-markets/ts-sdk";
export function configureProgram(programId: Address<string>) {
  setActaProgramId(programId);
}

export function resetProgram() {
  clearActaProgramId();
}
```

For manual assembly, use `computeOrderId`, `findPositionPda`,
`orderSignatureInstruction` and `buildOpenPositionIx` from `/chain`.
The maker's Ed25519 verification instruction must immediately precede
`open_position` and verify the same 32-byte order ID. Put any ATA/setup
instructions before that pair.

## Vault planners

- `chain.flows.VaultDepositorPlanner`: derives request/escrow/ATA accounts and
  builds the four depositor transitions without hidden RPC or send effects.
- `chain.flows.VaultManagerPlanner`: binds actor/current-delegate roles, derives
  Vault capital accounts and builds processing batches of at most
  `VAULT_CAPITAL_BATCH_USERS` (3) users. Its
  `governance`, `trading`, and `swaps` planners cover typed timelocked updates,
  vault position lifecycles, and route-bound Jupiter spot/recovery instructions
  without hidden RPC or send effects.

Swap routes preserve account order and repeated canonical accounts. The vault
PDA signs inside CPI; route accounts do not require outer transaction signatures.

Vault managers can also build, sign and submit Jupiter rebalances through their own
RPC, without Acta WS/HTTP; see the [standalone example](https://github.com/acta-markets/acta-contract/blob/feat/new-vaults/ts-sdk/scripts/vault-rebalance-jupiter.md).

### Vault creation and seed authority

`CreateVault` is signed by Acta cold; its governance may be a different key.
Set `manager_stake_min_bps` / `managerStakeMinBps` to 500–10000. Governance subsequently
calls planner `bootstrap(recipient, amount)`, paying from its own canonical main
ATA. Recipient need not sign. Bootstrap assigns the recipient once; supply zero
after burn or exit does not allow another Bootstrap or HWM reset.

`top_up_manager_stake(amount, main_price, second_price)` (Rust) /
`topUpManagerStake(amount, mainPriceUpdate, secondPriceUpdate)` (TypeScript) also uses governance funds and
signature. It computes a fresh boundary and mints to manager stake. After bootstrap,
`apply_fee_recipient_update(current, next)` / `applyFeeRecipientUpdate(current, next)`
changes the recipient immediately with governance alone, in any valid phase/safety.
It binds the expected current address and redirects all still-locked seed and fee
shares without moving capital; already released shares stay with their owner.

Stake percentage changes use generated `SetVaultManagerStakeMinBps` (80) wrapped
in the existing protocol Queue/Execute helpers. GlobalConfig delay applies,
including 0. Execution requires empty Idle/Unpriced and sufficient live stake.
Fees proposals change fee rates only. Event `VaultSeedPolicySet` (69) publishes
the initial recipient and later cold policy changes. Bootstrap wire: 41 bytes,
9 accounts; TopUp: 9 bytes, 17 accounts. Update builders together with program.

## Accounts and order encoding

Decoded account fetchers check supported versions, flags,
reserved header bytes and valid live Position statuses. The same validators are
exported from `/chain` for callers that decode account bytes themselves.

Orders are signed over the 32-byte `orderId = sha256(preimage182)`, not over the
preimage. Use `Uint8Array(32)` in chain APIs and 64-character hex in WS messages.
`computeOrderId`, `encodeOrderPreimage` and `orderSignatureInstruction` share this
encoding. `NonceGenerator` uses Xoshiro256++ with an optional seed and
`crypto.getRandomValues` when available.

## Wire metadata

The SDK requires server time in `Welcome`, credential expiry in `AuthSuccess`,
send time in `RfqBroadcast`, `order_version` in order lifecycle pushes, and the
instruction index in each known `ChainEvent`. Missing or invalid values in these
fields are rejected before dispatch. `*_unix_ms` uses
milliseconds; `expires_at` uses Unix seconds and limits credential reuse, not
an authenticated socket's lifetime. Identify chain events by
`(signature, instruction_index)`.

## Chain helper input boundaries

Use `bigint` for u64 values above `Number.MAX_SAFE_INTEGER`. The OpenPosition
wrapper and generated Open encoder reject unsafe numeric inputs; the wrapper,
order-price arithmetic and expiry PDA/GPA helpers also reject negative/out-of-range
u64 values. Signature helpers accept exactly 64 bytes in a `Uint8Array` (including
Node `Buffer`), not a base58 string. Decode an encoded signature before calling them.

Oracle `feedId` begins at byte 64 (`ORACLE_OFFSET_FEED_ID`); Oracle has no authority field.

`buildSettlePositionIx` requires a writable `taker` for either `unwrapUserSol: true`
or `flags: 1`. Low-level generated settlement builders describe only the nine base
accounts; callers must append this tenth account themselves for unwrap.
When migrating code that previously combined `flags: 1` with a manual account
append, pass `taker` to the high-level builder and remove the manual append.

Outgoing WS strings cannot use the reserved bigint encoding prefix. `acceptQuote`
requires a UUID `rfqId`; valid full-range bigint nonces retain their existing wire format.

Incoming WS frames with unsafe numeric values are rejected before dispatch;
`unsafe_integer` is reported once per message type per connection. Nonces must be
unsigned decimal u64 values and retain all 64 bits. Decimal/exponent notation is
rejected for nonces and order price, strike, quantity and timestamp fields before
JSON parsing can round them. Analytics floats remain supported; numeric literals
outside the safe integer range are rejected. Plain integers may equal MAX_SAFE_INTEGER.
Bootstrap, manager top-up and token approval also reject lossy numeric amounts;
use bigint for larger amounts. Attested-price flows accept calculation version 1.

Sizing helpers accept underlying decimals in 0..18 and require exact, safe integer
strikes and atomic quantities. `quoteAmountToQuantity` accepts fractional human
amounts and rounds to atoms, rejecting an output above `Number.MAX_SAFE_INTEGER`.
This remains floating-point UI conversion; validate the resulting quantity against
the market's size rule before submitting it.

## USD trading statistics

`GlobalStats.usd`, when provided by the server, separates `notional_24h` from
`premium_24h`. Both are exact decimal dollar strings; use a decimal parser for exact accounting. `priced_trades_24h` counts confirmed trades
with stored oracle valuations. Compare it with `total_trades_24h` for coverage.
The snapshot uses submission-time prices, including the quote token's USD price;
missing historical prices are not reconstructed. Legacy numeric volume/price
fields retain their raw-unit meanings and are not USD values.

## Development

```bash
yarn install
yarn build
yarn test
```

`yarn build` regenerates TypeScript instructions/codecs from the IDL and builds
ESM and CommonJS outputs. `yarn gen:codama` regenerates both TS and Rust bindings;
`yarn test:package` checks the built package's exports.

## Documentation

[Integration guides](https://beta.acta.markets/docs)

## License

MIT
